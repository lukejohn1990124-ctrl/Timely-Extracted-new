
DROP INDEX idx_email_templates_user_id;
DROP TABLE email_templates;
