
DROP INDEX idx_reminder_logs_sent_at;
DROP INDEX idx_reminder_logs_invoice_id;
DROP TABLE reminder_logs;
