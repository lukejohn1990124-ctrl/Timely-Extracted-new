
ALTER TABLE email_providers DROP COLUMN provider_type;
ALTER TABLE email_providers DROP COLUMN smtp_secure;
ALTER TABLE email_providers DROP COLUMN smtp_username;
ALTER TABLE email_providers DROP COLUMN smtp_port;
ALTER TABLE email_providers DROP COLUMN smtp_host;
