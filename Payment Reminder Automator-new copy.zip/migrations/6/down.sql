
DROP INDEX idx_integrations_provider;
DROP INDEX idx_integrations_user_id;
DROP TABLE integrations;
