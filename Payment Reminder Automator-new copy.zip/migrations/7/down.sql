
ALTER TABLE integrations DROP COLUMN user_identifier;
