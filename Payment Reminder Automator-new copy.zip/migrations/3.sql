
CREATE TABLE email_templates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT,
  name TEXT NOT NULL,
  tone TEXT,
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  is_custom BOOLEAN DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_email_templates_user_id ON email_templates(user_id);

INSERT INTO email_templates (user_id, name, tone, subject, body, is_custom) VALUES
  (NULL, 'Friendly', 'Casual and warm', 'Quick reminder about Invoice {invoice_number}', 'Hi {client_name},

Just wanted to send a friendly reminder that invoice {invoice_number} for ${amount} is now {days_overdue} days past due.

I understand things get busy! If you have any questions about the invoice or need to discuss payment arrangements, please don''t hesitate to reach out.

Thanks so much!', 0),
  (NULL, 'Professional', 'Formal and business-like', 'Payment Reminder: Invoice {invoice_number}', 'Dear {client_name},

This is a reminder that invoice {invoice_number} dated {invoice_date} for ${amount} is currently {days_overdue} days overdue.

Please remit payment at your earliest convenience. If you have already sent payment, please disregard this notice.

If you have any questions regarding this invoice, please contact us.

Best regards', 0),
  (NULL, 'Urgent', 'Direct and firm', 'Immediate Action Required: Invoice {invoice_number}', 'Attention {client_name},

Invoice {invoice_number} for ${amount} is significantly overdue by {days_overdue} days. Immediate payment is required to avoid further action.

Please make payment immediately or contact us to discuss this matter.

This is an urgent matter that requires your immediate attention.', 0);
