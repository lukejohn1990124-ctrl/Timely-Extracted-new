
ALTER TABLE scheduled_reminders DROP COLUMN bulk_group_id;
