
CREATE TABLE reminder_rules (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  name TEXT NOT NULL,
  days_overdue INTEGER NOT NULL,
  is_enabled BOOLEAN DEFAULT 1,
  template_id INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_reminder_rules_user_id ON reminder_rules(user_id);
CREATE INDEX idx_reminder_rules_is_enabled ON reminder_rules(is_enabled);
