
ALTER TABLE integrations ADD COLUMN user_identifier TEXT;
