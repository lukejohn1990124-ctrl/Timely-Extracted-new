
DROP INDEX idx_reminder_rules_is_enabled;
DROP INDEX idx_reminder_rules_user_id;
DROP TABLE reminder_rules;
