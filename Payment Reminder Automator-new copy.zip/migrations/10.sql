
ALTER TABLE scheduled_reminders ADD COLUMN bulk_group_id TEXT;
