
CREATE TABLE reminder_logs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_id INTEGER NOT NULL,
  reminder_rule_id INTEGER,
  sent_at TIMESTAMP NOT NULL,
  status TEXT NOT NULL,
  error_message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_reminder_logs_invoice_id ON reminder_logs(invoice_id);
CREATE INDEX idx_reminder_logs_sent_at ON reminder_logs(sent_at);
