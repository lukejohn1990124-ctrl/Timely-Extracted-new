
CREATE TABLE scheduled_reminders_new (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
invoice_id INTEGER NOT NULL,
schedule_type TEXT NOT NULL,
days_overdue INTEGER NOT NULL,
template_id INTEGER,
template_data TEXT,
recipient_emails TEXT NOT NULL,
scheduled_date DATE NOT NULL,
is_sent BOOLEAN DEFAULT 0,
sent_at TIMESTAMP,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO scheduled_reminders_new 
SELECT id, user_id, invoice_id, schedule_type, days_overdue, template_id, NULL, 
       recipient_emails, scheduled_date, is_sent, sent_at, created_at, updated_at 
FROM scheduled_reminders;

DROP TABLE scheduled_reminders;

CREATE TABLE scheduled_reminders (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id TEXT NOT NULL,
invoice_id INTEGER NOT NULL,
schedule_type TEXT NOT NULL,
days_overdue INTEGER NOT NULL,
template_id INTEGER,
template_data TEXT,
recipient_emails TEXT NOT NULL,
scheduled_date DATE NOT NULL,
is_sent BOOLEAN DEFAULT 0,
sent_at TIMESTAMP,
created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO scheduled_reminders
SELECT * FROM scheduled_reminders_new;

DROP TABLE scheduled_reminders_new;
