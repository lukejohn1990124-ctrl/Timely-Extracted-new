
ALTER TABLE email_providers ADD COLUMN smtp_host TEXT;
ALTER TABLE email_providers ADD COLUMN smtp_port INTEGER;
ALTER TABLE email_providers ADD COLUMN smtp_username TEXT;
ALTER TABLE email_providers ADD COLUMN smtp_secure BOOLEAN DEFAULT 1;
ALTER TABLE email_providers ADD COLUMN provider_type TEXT DEFAULT 'api';
