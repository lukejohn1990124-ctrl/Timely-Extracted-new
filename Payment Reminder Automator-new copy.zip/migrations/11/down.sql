
DROP INDEX idx_email_providers_user;
DROP TABLE email_providers;
