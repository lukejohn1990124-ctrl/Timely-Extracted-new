
DROP INDEX idx_invoices_due_date;
DROP INDEX idx_invoices_status;
DROP INDEX idx_invoices_user_id;
DROP TABLE invoices;
