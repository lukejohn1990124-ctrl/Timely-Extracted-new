
CREATE TABLE email_providers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  provider_name TEXT NOT NULL,
  api_key TEXT NOT NULL,
  from_email TEXT,
  from_name TEXT,
  is_active BOOLEAN DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_email_providers_user ON email_providers(user_id, provider_name);
