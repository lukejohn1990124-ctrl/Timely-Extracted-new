
CREATE TABLE scheduled_reminders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  invoice_id INTEGER NOT NULL,
  schedule_type TEXT NOT NULL,
  days_overdue INTEGER NOT NULL,
  template_id INTEGER NOT NULL,
  recipient_emails TEXT NOT NULL,
  scheduled_date DATE NOT NULL,
  is_sent BOOLEAN DEFAULT 0,
  sent_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_scheduled_reminders_user_id ON scheduled_reminders(user_id);
CREATE INDEX idx_scheduled_reminders_invoice_id ON scheduled_reminders(invoice_id);
CREATE INDEX idx_scheduled_reminders_scheduled_date ON scheduled_reminders(scheduled_date);
