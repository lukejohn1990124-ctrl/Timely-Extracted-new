# Todo
- #2: Test Gmail draft creation flow end-to-end
- #3: Add Outlook OAuth flow for draft creation
